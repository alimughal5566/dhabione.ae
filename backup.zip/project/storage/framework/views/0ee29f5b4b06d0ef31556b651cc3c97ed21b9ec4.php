						<div class="item-filter">

							<ul class="filter-list">
								<li class="item-short-area">
										<p><?php echo e($langg->lang64); ?> :</p>
										<select id="sortby" name="sort" class="short-item">
	                    <option value="date_desc"><?php echo e($langg->lang65); ?></option>
	                    <option value="date_asc"><?php echo e($langg->lang66); ?></option>
	                    <option value="price_asc"><?php echo e($langg->lang67); ?></option>
	                    <option value="price_desc"><?php echo e($langg->lang68); ?></option>
										</select>
								</li>
							</ul>
						</div>
