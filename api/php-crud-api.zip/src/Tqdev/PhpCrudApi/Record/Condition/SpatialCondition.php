<?php

namespace Tqdev\PhpCrudApi\Record\Condition;

class SpatialCondition extends ColumnCondition
{
}
