<?php
$settings['driver'] = 'sqlsrv';
