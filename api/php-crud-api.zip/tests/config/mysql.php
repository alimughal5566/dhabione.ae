<?php
$settings['driver'] = 'mysql';
